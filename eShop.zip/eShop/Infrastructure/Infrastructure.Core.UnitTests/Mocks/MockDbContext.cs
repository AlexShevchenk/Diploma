namespace Infrastructure.Core.UnitTests.Mocks;

public class MockDbContext : DbContext
{
}