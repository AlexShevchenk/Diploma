namespace Infrastructure.Core.Identity;

public static class AuthPolicy
{
    public const string AllowClientPolicy = "AllowClient";

    public const string AllowEndUserPolicy = "AllowEndUser";
}