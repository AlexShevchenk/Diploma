namespace Infrastructure.Core.Identity;

public static class AuthScheme
{
    public const string Internal = "Internal";

    public const string Site = "Site";
}