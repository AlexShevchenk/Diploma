﻿namespace Infrastructure.Core.Configuration
{
    public class RoutingConfig
    {
        public const string DefaultRoute = "api/v1/[controller]/[action]";
    }
}
