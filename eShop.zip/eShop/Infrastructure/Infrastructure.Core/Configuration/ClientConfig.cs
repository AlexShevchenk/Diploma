﻿namespace Infrastructure.Core.Configuration;

public class ClientConfig
{
    public string Id { get; set; } = null!;
    public string Secret { get; set; } = null!;
}