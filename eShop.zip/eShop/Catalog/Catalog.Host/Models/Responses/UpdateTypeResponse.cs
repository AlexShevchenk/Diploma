﻿namespace Catalog.Host.Models.Responses
{
    public class UpdateTypeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
