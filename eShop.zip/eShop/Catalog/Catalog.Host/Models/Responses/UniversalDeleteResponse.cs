﻿namespace Catalog.Host.Models.Responses
{
    public class UniversalDeleteResponse
    {
        public bool Result { get; set; }
    }
}
