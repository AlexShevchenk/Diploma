﻿namespace Catalog.Host.Models.Responses
{
    public class UpdateBrandResponse
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
