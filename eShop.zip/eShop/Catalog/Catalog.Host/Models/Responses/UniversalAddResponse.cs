﻿namespace Catalog.Host.Models.Responses
{
    public class UniversalAddResponse
    {
        public int? Id { get; set; }
    }
}
