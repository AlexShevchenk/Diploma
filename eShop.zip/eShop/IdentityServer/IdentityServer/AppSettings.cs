﻿namespace IdentityServer
{
    public class AppSettings
    {
        public string MvcUrl { get; set; }
    }
}